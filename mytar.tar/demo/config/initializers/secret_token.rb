# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Demo::Application.config.secret_token = '9a9db0a3f9e8d23eaf16434e4160e7c9e4b89b2c125e36a801ad0a7a8fefd89ec5940c2e0560dcb5d50c407ead2616a845ce7aa96aa9296a7e6120acf7fcb61e'
