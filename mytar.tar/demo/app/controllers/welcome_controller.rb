class WelcomeController < ApplicationController
end
class WelcomeController < ApplicationController
	def say
	end
end
def index
end
